export enum WorkerIdentify {
    MAIN_THREAD_IDENTIFY = 'main',
}

export enum BasicAction {
    REGISTER = 'register'
}